package com.classdemomicroarch.sendnotificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendNotificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SendNotificationServiceApplication.class, args);
	}

}
