package com.classdemomicroarch.createuserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
