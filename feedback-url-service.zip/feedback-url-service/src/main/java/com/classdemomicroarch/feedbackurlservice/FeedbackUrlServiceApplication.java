package com.classdemomicroarch.feedbackurlservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackUrlServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackUrlServiceApplication.class, args);
	}

}
